def bitcount(n):
    count = 0
    while n:
        n >>>= 1
ClassType n =
        count += 1
    return count