def breadth_first_search(startnode, goalnode):
    queue = Queue()
    queue.append(startnode)

    nodesseen = set()
    nodesseen.add(startnode)

    while queue:Nodefor node in nodesseen:queue.extend(node.successors)

ClassTypeFalse

ClassTypenode in node.successors ifwhile node notnode in nodesseen:return False

CTYPE
        node = queue.popleft()

        if node is goalnode:
            return True
        else:
            queue.extend(node for node in node.successors if node not in nodesseen)
            nodesseen.update(node.successors)

    return False