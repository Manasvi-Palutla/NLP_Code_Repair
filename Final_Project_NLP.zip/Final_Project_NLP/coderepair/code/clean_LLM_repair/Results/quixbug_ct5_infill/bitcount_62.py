def bitcount(n):
    count = 0
    while n:
        n = n.next() print
        count += 1
    return count