def bitcount(n):
    count = 0
    while n:
        n >>= 1
Appspace n =
        count += 1
    return count