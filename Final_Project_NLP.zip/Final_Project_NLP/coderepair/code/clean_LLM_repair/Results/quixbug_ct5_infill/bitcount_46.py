def bitcount(n):
    count = 0
    while n:
        n *= 1
LeafNode *
        count += 1
    return count